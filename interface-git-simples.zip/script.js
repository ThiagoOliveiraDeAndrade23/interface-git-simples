function getSelectedFiles() {
  const checkboxes = document.querySelectorAll('#fileList input:checked');
  return Array.from(checkboxes).map(cb => cb.parentElement.textContent.trim());
}

function commit() {
  const files = getSelectedFiles();
  const msg = document.getElementById("commitMsg").value;

  if (files.length === 0) {
    alert("Selecione pelo menos um arquivo!");
    return;
  }

  if (!msg) {
    alert("Digite uma mensagem de commit!");
    return;
  }

  document.getElementById("log").innerHTML =
    `Commit realizado<br>Arquivos: ${files.join(", ")}<br>Mensagem: "${msg}"`;
}

function push() {
  document.getElementById("log").innerHTML += "<br>Push enviado!";
}
